# XYZ Realty Owner Desk

Owner dashboard (leads, properties, site visits, call logs) for the XYZ Realty voice-agent project.
Single-file static app: HTML + vanilla JS, talks directly to Supabase (auth + RLS) and an n8n webhook (outbound call).
Koi build step nahi hai.

```
xyz-owner-desk/
├── public/
│   └── index.html     # poora app
├── render.yaml        # Render Blueprint (static site + security headers)
├── .gitignore
└── README.md
```

## Render par deploy

1. Is folder ko GitHub / GitLab repo me push karo.
2. Render dashboard > **New > Blueprint** > repo chuno. `render.yaml` apne aap detect ho jayega.
3. **Apply** dabao. Kuch env var ya build command nahi chahiye.
4. Deploy hone ke baad URL milega: `https://xyz-owner-desk.onrender.com` (ya custom domain).

Manual tareeka (Blueprint ke bina): **New > Static Site**, Build Command khali, Publish Directory `public`.
Phir security headers dashboard me *Settings > Headers* se daalne honge.

## Deploy ke baad zaroor check karo

- **n8n webhook CORS:** abhi `Allowed Origins = *` hai, isliye Render URL se bhi call chalegi, kuch badalna nahi.
  Agar baad me origin restrict karo, to apna Render URL (jaise `https://xyz-owner-desk.onrender.com`) add karna.
- **Supabase:** auth ke liye redirect URL ki zaroorat nahi (`detectSessionInUrl:false`, sirf email + password login).
  Data protection RLS aur `dashboard_access()` function par tikhi hai. Publishable key browser me rakhna theek hai.
  Login ke baad ek baar check karo ki Overview me data aa raha hai.
- **CSP:** page ke andar `<meta>` CSP hai. `render.yaml` ka header uske upar `frame-ancestors 'none'` jodta hai,
  jo meta tag se possible nahi hai. Dono saath lagte hain.
- Agar Supabase project ya n8n URL badle, to `public/index.html` me `SUPABASE_URL`, `SUPABASE_KEY`, `OUTBOUND_URL`
  **aur** upar wale CSP meta ke `connect-src` dono badalna.

## Local me chalana

```bash
cd public
python3 -m http.server 8080
# http://localhost:8080 kholo
```

Local se webhook ke liye n8n CORS me `http://localhost:8080` bhi allow karna padega.
